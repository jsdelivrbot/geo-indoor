package test;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Test {
	
	// Wait time
	private static void espera(int segundos){
		try {
			Thread.sleep(segundos);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	// Poi creation
	private static void poiCreation(WebDriver driver, int position, String type, String name){
				// Builder
				Actions builder = new Actions(driver);
				
				// Put poi 
				WebElement poi = driver.findElement(By.id("draggable-poi"));
				builder.dragAndDropBy(poi, position, 50).perform();
				
				espera(2000);
				
				// Put poi name
				WebElement poi_name = driver.findElement(By.id("poi-name"));
				poi_name.sendKeys(name);
				
				espera(2000);
				
				// Put poi description
				WebElement poi_description = driver.findElement(By.id("poi-description"));
				poi_description.sendKeys("DESCRIPCI�N DEL POI");
				
				espera(2000);
				
				// Select poi type
				WebElement poi_select = driver.findElement(By.xpath("//*[@id=\"map-canvas\"]/div/div/div[1]/div[4]/div[4]/div/div[2]/div[1]/div/form/fieldset[3]/select"));
				Select my_select = new Select(poi_select);
				my_select.selectByVisibleText(type);
				
				espera(3000);
				
				if(type.contentEquals("Entrance")){
					WebElement poi_entrance = driver.findElement(By.id("poi-entrance"));
					poi_entrance.click();
					espera(2000);
				}
				
				// Poi submit
				WebElement poi_submit = driver.findElement(By.xpath("//*[@id=\"map-canvas\"]/div/div/div[1]/div[4]/div[4]/div/div[2]/div[1]/div/form/div/fieldset[1]/button"));
				poi_submit.click();
				
	}
	private static String notificacion (WebDriver driver){
		// Notification panel
		WebElement notification_panel = driver.findElement(By.xpath("//*[@id=\"notification_panel\"]"));
		String notificationText = notification_panel.getText();
		return notificationText;
	}
	// # --- # START TEST # --- #
	public static void main(String[] args) {
		// Web driver
		WebDriver driver;
		if(args.length > 0 && args[0].contentEquals("1")){
			// Google Chrome
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Juan Pedro\\eclipse\\chromedriver.exe");
			driver = new ChromeDriver();
		}else{
			// Firefox
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\Juan Pedro\\eclipse\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		
		driver.manage().window().maximize();
		// Page (Remember launch geooindor)
		driver.get("http://127.0.0.1:9000/");
		espera(2000);
		
		
		// Go to the geoindoor page
		WebElement architectButton = driver.findElement(By.id("architect"));
		architectButton.click();
		
		espera(3000);
		
		// Login on geoindoor 
		WebElement architectLogin = driver.findElement(By.id("login"));
		architectLogin.click();
		
		espera(3000);
		
		// YOU HAVE TO INTRODUCE YOUR ACCOUNT
		// YOU CAN USE THIS ->
		// USERNAME: testseleniumgeoindoor@gmail.com
		// PASSWORD: testseleniumgeoindoor12345
		
		// # --- # BUILDING CREATION TEST # --- #
	
		WebElement createBuilding = null;
		int flag = 0;
		while(flag == 0){
			try{
				createBuilding = driver.findElement(By.xpath("//*[@id=\"draggable-building\"]"));
				flag = 1;
			}catch(Exception e){
				flag = 0;
				espera(3000);
			}
		}
		espera(3000);
		
		Actions builder = new Actions(driver);
		builder.dragAndDropBy(createBuilding, -450, 50).perform();
		
		espera(2000);
		
		// Avoid public view
		WebElement b_public_view = driver.findElement(By.xpath("//*[@id=\"building-published\"]"));
		b_public_view.click();
		
		espera(1000);
		
		// Put name of building
		WebElement building_name_no = driver.findElement(By.xpath("//*[@id=\"building-name\"]"));
		building_name_no.sendKeys("EDIFICIO NO SE CREAR�");
		
		espera(1000);
		
		// Close the editor building
		WebElement b_close = driver.findElement(By.xpath("//*[@id=\"map-canvas\"]/div/div/div[1]/div[4]/div[4]/div/div[2]/div[1]/form/div/fieldset[2]/button"));
		b_close.click();
		
		espera(2000);
		String notificationText;
		int max = 0;
		do {
			max++;
			// Come back editor building
			builder.dragAndDropBy(createBuilding, -450, 50).perform();
			
			espera(2000);
			
			// Put name of building
			WebElement building_name_ok = driver.findElement(By.xpath("//*[@id=\"building-name\"]"));
			building_name_ok.sendKeys("EDIFICIO DE PRUEBA");
			
			espera(2000);
			
			// Avoid public view
			WebElement public_view = driver.findElement(By.xpath("//*[@id=\"building-published\"]"));
			public_view.click();
			
			espera(2000);
			
			// Submit the building
			WebElement b_add = driver.findElement(By.xpath("//*[@id=\"map-canvas\"]/div/div/div[1]/div[4]/div[4]/div/div[2]/div[1]/form/div/fieldset[1]/button"));
			b_add.click();
			
			espera(1000);
			
			// Notification panel
			notificationText = notificacion(driver);
			
		} while(!notificationText.contains("Building added successfully.") && max < 4);
		
		if(!notificationText.contains("Building added successfully.")){
			driver.quit();
			System.out.println("No se ha a�adido correctamente el edificio");
		}
		
		// # --- # FLOORS TEST # --- #
		
		// Go to Floors tab
		WebElement floors_tab = driver.findElement(By.xpath("//*[@id=\"ctrl-bar-tablist\"]/li[2]/a"));
		floors_tab.click();
		
		/* # UPLOAD A FILE #
		 * 
		 * To upload a file is needed to know the path 
		 * and the name of file, so this process is not
		 * automatized
		 * 
		 */
		
		// Floor plan
		WebElement floor_plan = driver.findElement(By.id("input-floor-plan"));
		floor_plan.click();
		
		espera(3000);
		
		WebElement building_plan = null;
		flag = 0;
		while(flag == 0){
			try{
				building_plan = driver.findElement(By.id("canvas"));
				flag = 1;
			}catch(Exception e){
				flag = 0;
				espera(3000);
			}
		}
		
		espera(3000);
		
		// Move the plan
		builder.dragAndDropBy(building_plan, -450, 50).perform();
		
		espera(2000);
		
		// Record the plan
		WebElement submit_plan = driver.findElement(By.xpath("//*[@id=\"ctrl-bar-floors\"]/div[1]/div[2]/div[2]/div[1]/div[2]/button[1]"));
		submit_plan.click();
		
		espera(2000);
		
		// Notification panel
		notificationText = notificacion(driver);
		
		espera(3000);
		
		if(!notificationText.contains("Successfully added new floor") && !notificationText.contains("Successfully uploaded new floor plan.") ){
			driver.quit();
			System.out.println("No se ha a�adido correctamente el plano");
		}
		
		// # --- # POIs TEST # --- #
		
		// Go to Pois tab
		WebElement poi_tab = driver.findElement(By.xpath("//*[@id=\"ctrl-bar-tablist\"]/li[3]/a"));
		poi_tab.click();
		
		espera(2000);
		
		poiCreation(driver, -600, "Entrance", "ENTRADA");
		
		espera(4000);
		
		poiCreation(driver, -500, "Toilets", "Ba�os");
		
		espera(3000);
		
		// Turn on the toggle edge mode
		WebElement poi_edge = driver.findElement(By.id("edge-mode-btn"));
		poi_edge.click();
		
		espera(2000);
		
		// Relation between pois
		WebElement poi_first = driver.findElement(By.xpath("//*[@id=\"map-canvas\"]/div/div/div[1]/div[4]/div[3]/div[2]/img"));
		poi_first.click();
		
		espera(2000);
		
		WebElement poi_second = driver.findElement(By.xpath("//*[@id=\"map-canvas\"]/div/div/div[1]/div[4]/div[3]/div[1]/img"));
		poi_second.click();
		
		espera(2000);
		
		// Turn on the add route mode
		WebElement poi_route = driver.findElement(By.id("botonroute"));
		poi_route.click();
		
		espera(2000);
		
		//# --- # ADD POIS TO THE ROUTE # --- #
		poi_first.click();
		
		espera(2000);
		
		// Button create route
		WebElement b_create_route = driver.findElement(By.xpath("//*[@id=\"poi-toolbox\"]/div/div[5]/button"));
		b_create_route.click();
		
		espera(4000);
		
		// Check button create route
		notificationText =notificacion(driver);
		if(!notificationText.contains("Name field must not be empty")){
			driver.quit();
			System.out.println("No se ha mostrado el error esperado");
		}
		
		espera(2000);
		
		// Button add poi to the route
		WebElement add_poi_route = driver.findElement(By.id("btnAddPoiToRoute"));
		add_poi_route.click();
		
		espera(2000);
		
		// Name of route
		WebElement name_poi_route = driver.findElement(By.name("nameRoute"));
		name_poi_route.sendKeys("PRUEBA");
		
		espera(2000);
		
		// Button create route
		b_create_route.click();
		
		espera(4000);
		
		// Check button create route
		notificationText = notificacion(driver);
		if(!notificationText.contains("The route should have at least 2 pois, remember to make the route in order")){
			driver.quit();
			System.out.println("No se ha mostrado el error esperado");
		}
		
		espera(1000);
		
		//Add second poi
		poi_second.click();
		
		espera(2000);
		
		// Button add poi to the route
		add_poi_route.click();
		
		espera(2000);
		
		// Button create route
		b_create_route.click();
		
		espera(2000);
		
		// Close pop-up of poi
		WebElement close_popup = driver.findElement(By.xpath("/html/body/div[1]/span/div[2]/div/div/div[1]/div[4]/div[4]/div[2]/div[3]"));
		close_popup.click();
		
		espera(2000);
		
		// Close pop-up of poi
		WebElement close_popup_s = driver.findElement(By.xpath("/html/body/div[1]/span/div[2]/div/div/div[1]/div[4]/div[4]/div[2]/div[3]"));
		close_popup_s.click();
		
		espera(2000);
		
		// ADD OTHER ROUTE
		
		// First
		poi_first.click();
		
		espera(2000);
		
		add_poi_route.click();
		
		// Second
		poi_second.click();
		
		espera(2000);
		
		add_poi_route.click();
		
		espera(2000);
		
		// Name of route
		name_poi_route.sendKeys("PRUEBA2");
		
		espera(2000);
		
		// Button create route
		b_create_route.click();
		
		espera(2000);
		// # --- # CLEAR AND REMOVE ROUTES # --- #
		
		// Route select
		WebElement select_routes = driver.findElement(By.id("showRoutes"));
		select_routes.click();
		
		Select my_select_routes = new Select(select_routes);
		
		espera(2000);
		
		// Select route
		my_select_routes.selectByVisibleText("0 PRUEBA2");
		
		espera(2000);
		
		// Clear button
		WebElement clear_button = driver.findElement(By.id("clearRoute"));
		clear_button.click();
		
		espera(4000);
		
		// Check clear button
		notificationText = notificacion(driver);
		if(!notificationText.contains("Route clear")){
			driver.quit();
			System.out.println("No se ha mostrado el mensaje esperado");
		}
		
		espera(1000);
		
		// Click select routes
		select_routes.click();
		
		// Select route
		my_select_routes.selectByVisibleText("0 PRUEBA");
		
		espera(2000);
		
		// Remove button
		WebElement remove_button = driver.findElement(By.xpath("//*[@id=\"top-container\"]/span/div[1]/button[2]"));
		remove_button.click();
		
		espera(4000);
		
		// Check remove button
		notificationText = notificacion(driver);
		if(!notificationText.contains("removed")){
			driver.quit();
			System.out.println("No se ha mostrado el mensaje esperado");
		}
		
		espera(1000);
		
		// Clear button
		clear_button.click();
		
		espera(2000);
		
		// Select routes
		select_routes.click();
		select_routes.click();
		
		select_routes.click();
		
		espera(3000);
		
		// Select route
		my_select_routes.selectByVisibleText("0 PRUEBA2");
		
		espera(3000);
		
		select_routes.click();
		
		espera(4000);
		
		// END
		driver.quit();

	}
	
	
	
	
	
	
	
	
	

}
